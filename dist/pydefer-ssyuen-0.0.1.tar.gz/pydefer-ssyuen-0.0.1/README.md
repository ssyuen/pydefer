# pydefer

pydefer aims to emulate the same experience you get from using Golang's `defer` keyword. pydefer allows you to execute a function around a given wrapped function after the wrapped function has executed.

## Prerequisites

``

## Installing

## Built With
